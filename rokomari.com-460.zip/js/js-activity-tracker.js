<!DOCTYPE html>
<html lang="en-US">
<head>
    <title>Just a moment...</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="/cdn-cgi/styles/challenges.css" rel="stylesheet">
    <meta http-equiv="refresh" content="35">

</head>
<body class="no-js">
    <div class="main-wrapper" role="main">
    <div class="main-content">
        <noscript>
            <div id="challenge-error-title">
                <div class="h2">
                    <span class="icon-wrapper">
                        <div class="heading-icon warning-icon"></div>
                    </span>
                    <span id="challenge-error-text">
                        Enable JavaScript and cookies to continue
                    </span>
                </div>
            </div>
        </noscript>
        <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/jsch/nojs/transparent.gif?ray=7b1c69e24fedc582')"></div>
        <form id="challenge-form" action="/static/200/dist/desktop/js/activity-tracker.js?__cf_chl_f_tk=YKeNEXxmFkVQEM04MjdwYjedMQbkjjJCQ4KpKfIRv8g-1680473549-0-gaNycGzNCKU" method="POST" enctype="application/x-www-form-urlencoded">
            <input type="hidden" name="md" value="v_BzYWkZNbI9o.9aUnYsH0X.Fegwyo_kpxDe.mw2us0-1680473549-0-AWhwFoHnG5HTesJFA9tizuv381_un8lCZoAKx_RA9kHUYYdtLBOw0wIDqKiU4yn31Ii0HBvaZXcnXb2Yn_DHF9CrQ4uiDWt7NzyBvGUHuKMeVWqeSy-D3IoKFxYgfW_DVGO507lQ-5pFlPPy4sh9L4ppBNtBRBsYsUJCuBOjGyA6ip0KtjNIQZKSK14dLrB1x9UreULVRLxl0j3HbMsOJM2yVXhpuiCA2rMS4KM59hmlUm_UUbXG_yiv9ks6E4lyVSpq0wwXVnxa5hIaczrz8-WT0M-MyWWXzl9grbA5cx1aIx0nenUGv-FxOw_ho89i8PoRKJvRgNAUSuPy4C5SbbheI0yWyVzJHYvlemVl9XRNnFxuQbrhQc4POHicLqNiYZp6nCzhn65qLM4xgh0dMrglx8lCQKdm5FZ7NzxN2QyBZZQmUrqq0R7FMRjTKL-HlAm6RTL6kpb4iT6zNCfA5sS6yhSou2R-ZsulYpi4ZkUMXU3QG88WkG7JkcZIA0Z2uDIT9xZ-__jVvee-kgAEDQXjTUbbcbwwxC0ceAhp6KynmE4qYnlXOVEaUOeG2pT1oK7yFeeb71YemEM149ySVxabgQ9wK0eTr8spZ_MhYVfohPapwP7JefdUrKxvmX4kNOEhOHkUxGazisN9kntpB1l1f3P38P8v1HEzRWXQq4R9i4jGjvh0I1ya8R4jiaK3-jtCwKKUvNmO4yNLPz0XcomTyiaZdy4dgy9zDNZgE_8xSEUDn5A1Lm4373PLLp9tERH1_ebuHtjR2bZ2yOEqcxtOmiH4aHS3rR0Tmauv1JBFLal4Fnw_YvCfFJJK0ZLrRxBfVoOksGCb3qzwEqQnJK5C9OYXnvXNCjPeOjWvKoJ3Wjg0_jXCWvhVWbd_-4y-j1xPckUhcpRgHeekK-nbgcfNs-6F0yI0xcIpXDzu8meJobkvjGmLPyuPJdxuTIdIdEpW1NE_H6m0bV3tRFdElijKDK0JwF2HrxDvQhTMODRvvOkjC4kgLkPjEoDCpKt-pIHwXxJIHeHW20Rk9yZtN-k8vY-X_W8HKTKol2iC4WD5kHd8ivmxOBC7dLTOK4mJpbB1ne3w27XG3uoUBi1QATnm-lCKqUVN04URusyqXebwVzuynPZpdoPhfwtrAGoTiT0bz8Grdj1t3agY8kxU_cQYWFSxfCCfkzqzspkAsMJLIIU3o1m2W-rnDS2guP70Tfesm9tj4Txm7Xrh73wb3KF0AnRI-3sb-bzeNEslFs2FS4ZlFRq_YdwZRh6gIfYAZ5Lv_VC1jjoH0KwvCYxwW_WedTFk7goP-gr-gF1N5I2HQkxlG-Bv2_uaQinW48Rx2OTWd5wq7mCIe7Z8cMsJHVpf01C7MrOSUT04j18aMRs43-yVsNZRDnLZM8eGJPBDUsb1meYtcSnrjxaq7vo_WYhFrcxX46kX6M-ci3mvFBHfEKPXrRHqAho457vOD_eYIeKE-Qg95c-_Cjpur8quQ6cDP5iWvgX0BKM_PgIj9hV9xc08NaDkHN7iu2v0DPMr4EPRm_GHdAUHdvlbGAxV5tnWy70N4g9dIuBBFC_YgpLrKNj5E2Tt2eeIV16tHd5NLUqdtZ8wjWfyu1d8T5xqAfMLbNaqPz6ZjAoFU1iH0LiG68WHhBQMsXGyfRJXeFj3pKSB3qBx6qk_-AM3PvfmXcSOciEweTe0ivU0A6dO99BGVglXrchqi6XyGHtrlo91EhXbj14eyKAPOrwdK9JIYmkiXoZsMP6fvviNEUGtphA4qqG_fUXuo9pFf1tJxOq5u4cfdtJaZCpPZzMQEZkzgKpFWCnNrbgq1NYLOwMwV8RGY_oSzpaZWduIS-5yHIHssnKM91RlvL8gim0dQe3bjI93A_88M3Fro9Xt2TjLbQGly171Zlkbajze-JzW2yqfTN4uCaHjLAvP9jP_7YeCdjJcD7sSCVU2--u1-aJyRdUx_DjHhfFePI87L4FCBL-vZo9qaORwBhfJVi0TpFqplCGJQTCLOweZxAwt5cK1ReoDgTfQcVGX7fRYyqxUQsbFUbUFRyqWwfCoOtnOEGlgvW2w6XV1GoYiRtWfs4GNXaLbsVMfjucwp7S_pu2NiV7Oz-72PWyCHWfvLiqheD3DO--78E1SmxKze5vI8z8AR50V">
        </form>
    </div>
</div>
<script>
    (function(){
        window._cf_chl_opt={
            cvId: '2',
            cZone: 'www.rokomari.com',
            cType: 'non-interactive',
            cNounce: '22439',
            cRay: '7b1c69e24fedc582',
            cHash: '21f3858024487d0',
            cUPMDTk: "\/static\/200\/dist\/desktop\/js\/activity-tracker.js?__cf_chl_tk=YKeNEXxmFkVQEM04MjdwYjedMQbkjjJCQ4KpKfIRv8g-1680473549-0-gaNycGzNCKU",
            cFPWv: 'b',
            cTTimeMs: '1000',
            cMTimeMs: '60000',
            cTplV: 5,
            cTplB: 'cf',
            cK: "",
            cRq: {
                ru: 'aHR0cHM6Ly93d3cucm9rb21hcmkuY29tL3N0YXRpYy8yMDAvZGlzdC9kZXNrdG9wL2pzL2FjdGl2aXR5LXRyYWNrZXIuanM=',
                ra: 'Tk9fVUE=',
                rm: 'R0VU',
                d: 'lKoeCUiXl6pXU8zAMY0PGsdOEw5xwCXvIkljNn2KcUAL5BV3IgdsZhaBEvkN7760Qmd9KJp3IaFnxXWbqfDQINRBamUQHZrNPtvgMLwEYeJrLGRvUB9OYFSZDXSWMzXr3Ta9MyzwzwJbQsWD/oA5zPYYsgBX2QrqbmE2uxer3ZXF7mIVS1CRozGNOmrW9c4uDssHZ9bgj2iheICzc2sC5Ws6kb3K4BW/RmehHeMiQCLqQc0stZDMmQuZ8AG8I/BderD7PCzKcGwDDJ3djX1GT4ELP4bAHdG+l9L1fD/sG1d2gvn5gpuQ1nTDCTeUG5aTEZ6+IieC8hjzzZ2ngRwBi6fwAayuXREXxl0r8WntKSEWLWScJBI/JtFy02+TL/+55m08WmFlWF/sOZn9LHfBbID1fwpk3Ehnt0/fXpIrRhWCH5sF1LXQPe6OyaKmtLX3CUQXyscm1o13wP7B7+P3lyJv8u5dOpnXQmbXlZQ+xDU7Jw0Un5J7MucH1ZaLuFdxdwgkNA+2hLNHdd0yIXsGsZC6ojaGVXMIsxz3ZrdgeoR1I6eTuzBY6MR7y5oJsCj5i91eaEykg4FWocYyCakttnqPsFf4ujDBPoZEt98r9SbwFNykBmG3JCHiYJaSWgjO',
                t: 'MTY4MDQ3MzU0OS4xNzYwMDA=',
                m: 'FAix6rD9h8lD1un7cTmp27xb70+mJpDfFCK9OikUPbc=',
                i1: '0BwO7aQMyytYBzDPRElR4g==',
                i2: 'Npj7bGUA+DfiQg4zm0Knrw==',
                zh: '1DVRNAlOk2GcTXXG7AR1pZWNZiJTq6j1VBfddTmyiJI=',
                uh: 'DV4j3Tmrbi5Rs1q3ahwVS6SgbPbI7np5884QO1u1Cgg=',
                hh: 'sZG2UFeZu81C28BydsmA6yuSPCKDPnnywA2izalVuLk=',
            }
        };
        var trkjs = document.createElement('img');
        trkjs.setAttribute('src', '/cdn-cgi/images/trace/jsch/js/transparent.gif?ray=7b1c69e24fedc582');
        trkjs.setAttribute('alt', '');
        trkjs.setAttribute('style', 'display: none');
        document.body.appendChild(trkjs);
        var cpo = document.createElement('script');
        cpo.src = '/cdn-cgi/challenge-platform/h/b/orchestrate/jsch/v1?ray=7b1c69e24fedc582';
        window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;
        window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;
        if (window.history && window.history.replaceState) {
            var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;
            history.replaceState(null, null, "\/static\/200\/dist\/desktop\/js\/activity-tracker.js?__cf_chl_rt_tk=YKeNEXxmFkVQEM04MjdwYjedMQbkjjJCQ4KpKfIRv8g-1680473549-0-gaNycGzNCKU" + window._cf_chl_opt.cOgUHash);
            cpo.onload = function() {
                history.replaceState(null, null, ogU);
            };
        }
        document.getElementsByTagName('head')[0].appendChild(cpo);
    }());
</script>


</body>
</html>
