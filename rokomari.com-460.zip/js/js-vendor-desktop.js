<!DOCTYPE html>
<html lang="en-US">
<head>
    <title>Just a moment...</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="/cdn-cgi/styles/challenges.css" rel="stylesheet">
    <meta http-equiv="refresh" content="35">

</head>
<body class="no-js">
    <div class="main-wrapper" role="main">
    <div class="main-content">
        <noscript>
            <div id="challenge-error-title">
                <div class="h2">
                    <span class="icon-wrapper">
                        <div class="heading-icon warning-icon"></div>
                    </span>
                    <span id="challenge-error-text">
                        Enable JavaScript and cookies to continue
                    </span>
                </div>
            </div>
        </noscript>
        <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/jsch/nojs/transparent.gif?ray=7b1c69e9d865ec44')"></div>
        <form id="challenge-form" action="/static/200/dist/desktop/js/vendor-desktop.js?__cf_chl_f_tk=kMGXfVf.b575rS7CHRQmF._UCD6dBil6yKxcRUGLVJg-1680473550-0-gaNycGzNCLs" method="POST" enctype="application/x-www-form-urlencoded">
            <input type="hidden" name="md" value="Omc8qaTi0wwTy7Mc4ipl3LLJZqD4adfz4Te3v_lUkNk-1680473550-0-ASSSZ_RRgXhx7i1idKObWv4JSygU4sq9PHMOuOiZBjO8LIWp1rY0XpnTmga9SW9nWXjy9JLOHgBkSeLbgGwQeADLyNlR0UGn2QNKr-gBQSzWuO1tiVO-fqnuYFmoyPqzsF7VXuiL8Vmvk9WB93AS4Q2z_A0cGiNBDKNC2C6sROHB-fUTeGoKrfZSa3c5m25PRCgHsh1CFDh2oa55u6RshkwmMxa6Ax9GSMMGqkavu5bzzarc7MrSpE-yCCIWQ-y1_lYKDRE2XxCvCd4BaT1UBgJddTFx2uNI7-2P5NE2ThBArdJXg0HbYjcvOz56uBpXcp1jPgRvymLNLsQm8VLNDUM-HZlbqVN3OvWQLV0CJR3LtbExCOo5uDx2O2IYIv80RafjEn7GmK112Hd9RIuaEXbhG_UOgjiIQFnq-3Ljo4nsm1AMoqjJLs3Dgzb2WEytzDE1fMeHhSNdWYzMu535Ra2-RVtYqrxPk39qh-p6nOeLGUK1RK1OfaYgc_ALpzQP3OaYWSS4DW9ryURd6n6uGFnmP_mPnRKhBukVBYO_T6Yhty2Z93iWEmd7W3w2qhS1PewSraryj6Dl7NqffkgBsCrn_DuuWTQclXicps2gK_l_dhox7n3sXoRbf3VImcHDHYKGrEnAeS1-dbjKpPIkwvXIyS1GE9AC-JYsOHTDZgjlLZVRu4JN0aPtBHvfvZRtrGG5cSi90FHViYOxY4iq-BEl9DulxsjaINWupX6TeH-_vuKkDvwP8EKfXHsrei8liEMS59a3YufWsBYWfEKYa2mZEf-aH_jrR4v0HXP4mSVhBIV4rtL4sRorf067pIsOVGWR3YTLgivs53HEEnOhruP_2RU4_w34XsC108ndnchkvEGrW7y-ue6JGfq853oZz0QO3iOaPXeKKNmY8btwBfN58EOf3qr1yJrisPq2wu4VAB2rMhimpTXWvRwldy3tJ3bw8nd44tVRV9scr3J_h6a366lfVxEqGme2P29bULHwdTg43N-E2xHrpvp_KgoS4hlxLDFnQRXTPAyxxDaPiBO2uMvkAY552ZRxE-mflugfTF27snZTLLNcOoaAzCxesmA4ikUf1nwVUuPr0MoUYMBkffnzVOJkE9NmqjV9WQ2JCLHBM7JHxjJknMKqWdnGTufSAkHveLwxQ5-9CBNh60xJJNwmTnZ5JOpaboa8_RFDUmfCaWWHNYBsi8vbSaqDrujuNFOkqXYCxusn7RYah7_pTBfDgcMcP0IwZvpVgA0DexNyIngSpK4Deo9mfFEdz_WLVw9tRzqx2-tzFkyZC2LuPaILYKU-XRp4WiY0cTp7qAekriHe_o3QGkUdawa0GdPv38T5WNHQTkEmCdGQovx5rYoYP6bcNVUZjEK5nS3CCZsV-TjvU73sJjlntDNdFxB2VMePThNjJ6eEm3PsFtLuxSwqfXwggrJzTy_jt_bIL_o_s2N-xbVHAXjG24v2U9QefeQJFpnuhZI3PCdMvLPendPn7_MRP47OcGTvBvAXZd1bvhFnu8EC9BNqG2xa_jtW3PAKYDPONdnUe31R30Im-AL_t3gpiDHM01N3CT8-c1bIQJxwpF9B-O8-vi5HtQNCl83LmtJe6Yhhux4uvM7QugeaAXBVJetA9GxDDtGkQWemktR26qXjGIVrKUg1nnLgxoc2MpqfBi_Qp8cXgwY5HKa9A0xbb2JeMJKtMC8OspJTgS30JqR41zO9vIGscmznb_fMm3aDJYhuf6psWp1s1t6lMfqX_JNckppdv0TH6qq3ZfrYOp6jWCkSaNMBkf6IhLhpZQemlOHUD_7vpESujswN-jVoxIFL1w-frZH08XCh5233b9wY3_XF4LIAo-Ng58tSQCNOxP95h-Ockgv_q0jzn6rel_Pcw6041Uk5t6hs17AqIUc86NmvkmdFFU4HkFREPFhkYr43u6lIotEgU7oLVck-qo0_NxqWkH40pxx9WZIMlUgfvDFJiZQDDe6wZLwkB9f_OXip0b7SCRygAdx2khKonlHmM58XrQcDwcgjX9sEFXFsLZ2u2ivwdXW9iF-ZXGVIwC-hCkMRIXncMu8Hg5A_Dm3Ke6ItfKgsHKP68gluAi1fkeSNsDif0xuiZH0aEBJ-CTWC1JsttK-H8JYeTjF-0M7Q3rkDT51_vLr6WcvtEA5bEgJnm2lEJw">
        </form>
    </div>
</div>
<script>
    (function(){
        window._cf_chl_opt={
            cvId: '2',
            cZone: 'www.rokomari.com',
            cType: 'non-interactive',
            cNounce: '42883',
            cRay: '7b1c69e9d865ec44',
            cHash: '3c25bb7596584ab',
            cUPMDTk: "\/static\/200\/dist\/desktop\/js\/vendor-desktop.js?__cf_chl_tk=kMGXfVf.b575rS7CHRQmF._UCD6dBil6yKxcRUGLVJg-1680473550-0-gaNycGzNCLs",
            cFPWv: 'b',
            cTTimeMs: '1000',
            cMTimeMs: '60000',
            cTplV: 5,
            cTplB: 'cf',
            cK: "",
            cRq: {
                ru: 'aHR0cHM6Ly93d3cucm9rb21hcmkuY29tL3N0YXRpYy8yMDAvZGlzdC9kZXNrdG9wL2pzL3ZlbmRvci1kZXNrdG9wLmpz',
                ra: 'Tk9fVUE=',
                rm: 'R0VU',
                d: 'zsDLRT//rqj4HJ0o+2lJWGD5ejwhuxjXlk4gFbK9Nadq+YufbQWLUTl0oG2R8X6EXLjpdedzD/WdMZRcMcGJBVgNXGP3eSTHBTBEVC0sq+N+O9mA4jR5gvLgB7sjcfqm+FMeS6E/sGw2TFhWIbtxm2RNnb/zNs48f8AFyvyWISWSvKCOSXlbznzV/mwbOBaGN99KKem7w1x4ADELeNNlxa+ajECJA2i0V0TmsuQSN324k7bYeXYlKBJTHgX0ZGTzlMMBLfSNI2jqYVXxAv7psfdFd7/gq8QWLgzlrziKsWb+y3yCuea7GX6kzjmc3wr1ZAoF6loHdv+0mNbQisAGMR3haF/7N8hAv5oy8B1pTEk22/1bqX+LESBoU3D0rikm9Jm9pgj3hbD8e+UMs+pH4/yWIopxbpRDsMUZy1MKHoJK0VAHfXekG6RH028Dy/jK/K7ntUH6kafTvYcrX/j09WBOtFjpRfHUEkMXtkWRJHjUhzbviEIz4hluU2drpNv0ivDzsx6k+vwtTuFf2DyZkclvn6wm05ClpanHgORVlEiB+l9qLKVI92fKJQOvGL9K1AJVvVKZwUcyrSWDxtPXNK4XFenZDlx4Ei6lgC46r5ODBF9AEQneLbhKxkzCxfom',
                t: 'MTY4MDQ3MzU1MC4zODEwMDA=',
                m: 'd2YGw8djkXdzIn66qqNrOlljGFaQ2o8fLlKGaQArhQs=',
                i1: 'gh7TEpEnJwLUj4SAS1yVag==',
                i2: 'uPhj5v5H8e/e1xgskFNtSw==',
                zh: '1DVRNAlOk2GcTXXG7AR1pZWNZiJTq6j1VBfddTmyiJI=',
                uh: 'DV4j3Tmrbi5Rs1q3ahwVS6SgbPbI7np5884QO1u1Cgg=',
                hh: 'sZG2UFeZu81C28BydsmA6yuSPCKDPnnywA2izalVuLk=',
            }
        };
        var trkjs = document.createElement('img');
        trkjs.setAttribute('src', '/cdn-cgi/images/trace/jsch/js/transparent.gif?ray=7b1c69e9d865ec44');
        trkjs.setAttribute('alt', '');
        trkjs.setAttribute('style', 'display: none');
        document.body.appendChild(trkjs);
        var cpo = document.createElement('script');
        cpo.src = '/cdn-cgi/challenge-platform/h/b/orchestrate/jsch/v1?ray=7b1c69e9d865ec44';
        window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;
        window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;
        if (window.history && window.history.replaceState) {
            var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;
            history.replaceState(null, null, "\/static\/200\/dist\/desktop\/js\/vendor-desktop.js?__cf_chl_rt_tk=kMGXfVf.b575rS7CHRQmF._UCD6dBil6yKxcRUGLVJg-1680473550-0-gaNycGzNCLs" + window._cf_chl_opt.cOgUHash);
            cpo.onload = function() {
                history.replaceState(null, null, ogU);
            };
        }
        document.getElementsByTagName('head')[0].appendChild(cpo);
    }());
</script>


</body>
</html>
