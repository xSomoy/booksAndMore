<!DOCTYPE html>
<html lang="en-US">
<head>
    <title>Just a moment...</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="/cdn-cgi/styles/challenges.css" rel="stylesheet">
    <meta http-equiv="refresh" content="35">

</head>
<body class="no-js">
    <div class="main-wrapper" role="main">
    <div class="main-content">
        <noscript>
            <div id="challenge-error-title">
                <div class="h2">
                    <span class="icon-wrapper">
                        <div class="heading-icon warning-icon"></div>
                    </span>
                    <span id="challenge-error-text">
                        Enable JavaScript and cookies to continue
                    </span>
                </div>
            </div>
        </noscript>
        <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/jsch/nojs/transparent.gif?ray=7b1c69ea5c53c67c')"></div>
        <form id="challenge-form" action="/static/200/dist/desktop/js/common-desktop.js?v=1&amp;__cf_chl_f_tk=oI8XJDuDtJ1BPyGAuM9oioLeKSy1mHmTlKbpM4m4z5w-1680473550-0-gaNycGzNCKU" method="POST" enctype="application/x-www-form-urlencoded">
            <input type="hidden" name="md" value="eUhC6r3KLJ0ZoTgHI0XNebECbiQIEoocFAMU4r8vh60-1680473550-0-AQWBqJeSMJR3k_w52hycPdXhF2fHMrq4zXVeGrcpzaIPXqiPfEejmOuiWku3QgR-WN0OjP7tvtRrgskHzl2LcrEyithsFh9yfTKZ-Xe68vPTI8h3qjNXWUQ0YedNQRXsls1ulYFaV6P2twXoxljmT_GrWT3YZhTI7ei3VdRdUC1HsQbRUff-chTRYl-vIdYFiYQOCnAa8THfBYT5O1myHOqxcfqbKTLAK8oQdB5ipjdgFhhxeMg0hw45BnsjaSuL5nkTLAMRddwhFOS99jogLfwoJ2F9lZzpwNBqIzBqt_6ou_DLGaLVQwHsOMh-j-u9-jeUcyc5ciBjW9NiNuI3XW9txsxzlYe0fY1Md3HG0Le_BLjvWKhCQAEzjINUjwaKcF_LFiutl_CJQdWLQoPNu3MxC4MJyN5EDLKVCjqm9bHlanw91ukEPbyKlFKmY6h56Blxsc1AIelDqdTHCwzOSEEvT5LW0fXYXo73ou9EIw2fDiMl5AqeCANb5Y-DunqKSrwGxffFyVGz_5OkBZHbVTnziM-cfQBp3B61y2ndRV2JPNGsEN_nJ591qfy225xqkyNHwLuITrFDiw3-WE3aSLPAdaMHU_wZhJshizNhgWrjMYdmCHN8kX_EqDU8wdn0SVvu5wemR5ILInmopR_R1PodPhTIKj64RyQfdS-g92HdOaoh4KLAQxwuNcQhqirmT_4KQiJ3iWwUVLbr9k2W_kTs-D4P4OXIGv3N1QDWB2vOahbxXxGqgRk2a_W3Prjh4flR185N63A9UNMPHl7zxlYQBHmZyGWWLxd_4q4ElQzQiYapSFY7_0tcIW1koMtbU5fzmNL7f7FfddFF8KnImRJNQOFR3catRC2o4OheUPFPqx9OcXUzGkz_SAaSGApk7he3f9pviaw9YiwTJbtIhUpV4ltuSLcTjHbVzAWrwwUqQ2SOpOToteRiLMDIG01bzplBtCQR-3l1LlLxb6d7sNdDdiji60bgATDahx0OPXYat9aqKNeIV3QOCgl75zn3obloqSN1GZ0VqE5nR6mcgZK2qYd7vxEfAU5gy-SLuXG61OjEVnRet9Z_8VGDWF_F2LmQNDIV1mxefWAd_huORzrPjcRonfrH6sDMMWw8JQhMnzDtw6ZwSQQZrxavLIE7kKbSlNi2GkeoByjlB-OPLAGORpZpB37HMo2g2HW9Y2fIcWPi3E9VhoTdisIZrrOqEVnPGqQL2cPlrR4xz3VPzdEXTgTRQTpdhUvnEeDRr-Krd_7w-XaxYSMnlW44mWePWqqEwueHRqAwXTwl9MKxe5GpTdeXaJHXuGp797UEMKgNEmLIq0hwVDgHAlnuEBUOcIHZENadTv_6nrK1R3yKKntWeDtxeCBGtJzqndNixJ-C7COws8Xc7uLqpWwC4935cX1HjYkecfZx6moFQTU2ufbDZzB7HBhAHQQYqFSJr0t75vhdbqlbuxRUnWBs7GrLMnKQIxPBOk8P2V6Uzx9yeQjMMRfokohOog9oZTUYvvToXZGFIe7MIeyyKt88zpKwm8PBAvsl86iBFYSsNvYgndDyv5mv8GMJ0SYAh07K6ZQvPMzpbEhlIIYVy86bJtL8is9lmx7muQBFvlWZd0CvfyD6E9yyEFUkPSq2KBl8sHCAWoGCXP9RtY0RTzXe9VY0FZo5f6lr6c_Yy3FNQ5QPrkJLf5DwfMoarYJrro-rayDrUp9OFnPpJ0nd5p9-BwU2H1pn_E2BqQ9zQEgpqdXMOlgP68037pEjaLXa7VL_vpGo11Vop3w4U6N7tAiAeRzeUbZSz2Ku35J_gSmvjdt5l2Wc1_C1dgpRC47AJ-YbMbrfpu7zVbPhiEKODr3iZG02WYqLN5RucRbst35YJRZUf8dt1XmI2SmlzZEcl8S8z1NP4oDl4djpr32afQBDMr375q2SW_hhSB3PjZRAGFQ4nNQwkJ0MpxHVz0bJXyzrqBaP1lqbjw7vZ2llfkQl2tJYKUI8hBWuzt4yThIlzqTq8SjbIR92vZp3YYi_hTzQzw9G_IUaxPyTMtwueuVfQstLBf4on0dkloQYhPMvcisx7yOzTx_z9E5EWTyaMXfR9icULCkVo-AQ4l7M53Dgg4w7gdDTjmdfC_XOz2Jr3xtiHkwOVSKcXOggIiINnL1AkNo5">
        </form>
    </div>
</div>
<script>
    (function(){
        window._cf_chl_opt={
            cvId: '2',
            cZone: 'www.rokomari.com',
            cType: 'non-interactive',
            cNounce: '57415',
            cRay: '7b1c69ea5c53c67c',
            cHash: '59c9bf2e80ab815',
            cUPMDTk: "\/static\/200\/dist\/desktop\/js\/common-desktop.js?v=1&__cf_chl_tk=oI8XJDuDtJ1BPyGAuM9oioLeKSy1mHmTlKbpM4m4z5w-1680473550-0-gaNycGzNCKU",
            cFPWv: 'b',
            cTTimeMs: '1000',
            cMTimeMs: '60000',
            cTplV: 5,
            cTplB: 'cf',
            cK: "",
            cRq: {
                ru: 'aHR0cHM6Ly93d3cucm9rb21hcmkuY29tL3N0YXRpYy8yMDAvZGlzdC9kZXNrdG9wL2pzL2NvbW1vbi1kZXNrdG9wLmpzP3Y9MQ==',
                ra: 'Tk9fVUE=',
                rm: 'R0VU',
                d: 'TN65CHIu8TsPlDwm/vCV5Ff2xvvQGpnh6UTx6/Sktb3U3tnFxmlki58G07as77pOmD74UbhLKo95d1Rn7zc0gciuEOLQ1xDU+RsShU+yE0id2xHWqSuLnn0AGwE9Ltdp6OwCuIJBKlSbl5JbMhbIQWeL2mo6DlFwueFoupfjx5/3NzcgSK8+n1hMyZS6AnmfaVkKvKLNVjp1w5DiVDdc9j1k8I+7wULv0ylLJLDhofMGSVYJPDrUlvTNQVZSd0/JusGsfMOD0Uxx06cNz/WZtzKAgpUbZNwYcmJwBUQPW+0LV3T5ZqXEVaoC78GpbbHo2e9B+QameexrkDrOJ//YlpqnwzqeKeONOE2K9X/dP/20XH+nW/L27K0Ui02AtiT55FCgcwnVzcMLFA+ltsRt+W3gM/pmFVRPdjTQHC6veK7jenxPDR9TDIxjBaHYz+tR6jlpUUTexjF6rhFYEPOQwH/jDTNhKYsqDkmlgrkv+ekBGwL27iz+RmlLFObe/0rseOEZHi7TSbglYEEXJ1dUh65+n6kV4w78/Z60zcH9+CYj0m8nMSRUjdu1bwev/aqnddCssUEfrG9O8scb/qJ81sUIqUEalynsv/KLp1zOcuC3QgAe/LT9DTkkAT4jgxiH',
                t: 'MTY4MDQ3MzU1MC40NjIwMDA=',
                m: '4byiga8lr7jEPQw7tSUc6vErQZME5uhNrkZhhAw7Ap8=',
                i1: '0KXRKovh7e/Lkf+QzwFaRQ==',
                i2: 'Q0I9kZFVI/kdUcvTc3CIYg==',
                zh: '1DVRNAlOk2GcTXXG7AR1pZWNZiJTq6j1VBfddTmyiJI=',
                uh: 'DV4j3Tmrbi5Rs1q3ahwVS6SgbPbI7np5884QO1u1Cgg=',
                hh: 'sZG2UFeZu81C28BydsmA6yuSPCKDPnnywA2izalVuLk=',
            }
        };
        var trkjs = document.createElement('img');
        trkjs.setAttribute('src', '/cdn-cgi/images/trace/jsch/js/transparent.gif?ray=7b1c69ea5c53c67c');
        trkjs.setAttribute('alt', '');
        trkjs.setAttribute('style', 'display: none');
        document.body.appendChild(trkjs);
        var cpo = document.createElement('script');
        cpo.src = '/cdn-cgi/challenge-platform/h/b/orchestrate/jsch/v1?ray=7b1c69ea5c53c67c';
        window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;
        window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;
        if (window.history && window.history.replaceState) {
            var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;
            history.replaceState(null, null, "\/static\/200\/dist\/desktop\/js\/common-desktop.js?v=1&__cf_chl_rt_tk=oI8XJDuDtJ1BPyGAuM9oioLeKSy1mHmTlKbpM4m4z5w-1680473550-0-gaNycGzNCKU" + window._cf_chl_opt.cOgUHash);
            cpo.onload = function() {
                history.replaceState(null, null, ogU);
            };
        }
        document.getElementsByTagName('head')[0].appendChild(cpo);
    }());
</script>


</body>
</html>
