<!DOCTYPE html>
<html lang="en-US">
<head>
    <title>Just a moment...</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="/cdn-cgi/styles/challenges.css" rel="stylesheet">
    <meta http-equiv="refresh" content="35">

</head>
<body class="no-js">
    <div class="main-wrapper" role="main">
    <div class="main-content">
        <noscript>
            <div id="challenge-error-title">
                <div class="h2">
                    <span class="icon-wrapper">
                        <div class="heading-icon warning-icon"></div>
                    </span>
                    <span id="challenge-error-text">
                        Enable JavaScript and cookies to continue
                    </span>
                </div>
            </div>
        </noscript>
        <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/jsch/nojs/transparent.gif?ray=7b1c69e2ad85c690')"></div>
        <form id="challenge-form" action="/static/200/assets/common/js/ga4-event-emitter.js?__cf_chl_f_tk=klmLiDMCXIyfv8ItUHuGF1XKW3DtmPp5.Het93EaUWI-1680473549-0-gaNycGzNCLs" method="POST" enctype="application/x-www-form-urlencoded">
            <input type="hidden" name="md" value="JN1.Ak.YmHWvxWTcg3Ca1Rcnqq6LJRSed.Uw_TyUaUs-1680473549-0-AeQOm713WLrloxB_mzHnG0rlx9zIHVTcUdUi0u_tQD2VaZsw3Kk24Rht5y8zPMiV0RyagCGHrKyMIhZjjTF98wJwMlFvjzlc5QFU29vT2dZIkwSgs_3CBPXfFRO0Z6KQHECmlA6RWzmxZqaIs_MT-VW1570uMxXSJrMvim1nH9yJUmXgWjCJEyaYnJla7YX_dNl8_0j4P7pS49cziPca7qJqOB102bK-Krv9FAZAyUEfiw6Y7G0znbYalPWLLbT-RM3OFHE2OiUzlCiPfYxqSLDuX3gHA2k18q2-Y9zzpMR6yBNozOy-l0X1GVlP5PyDqKRJL3pTrbcezt3fKGNVhEaCDdjODI_m2C4A3Em8rqBsPs1uJ4x3IICZ9EdG6GbxsVt6E1KaAQFBfpQNAah1C1LmOlZXp_VuAHrbVJ75i85E6lr05MkunbFA5uP_kocLvXtsXBIah4ABn7AtzfTqUawMak8pmA1Z5J-ih632YH0PMtXCM90mxM9J3wt-mftI3ZZ0FcM3Nj7O0amuSOoFPPJZyWsZALQ-cOeMFyLpibHPkw9MkL6k-odJqbr9jBi5CvkRPAFrHv8ljmBxO40A9hvbBzt-4l9NmQMxiwJe2ST5Lpg5un0ogdQz2RNcgxjGei2eJl8KVzKPAEbZkSFBGQD7RBQ8f1fAq7UWhLaEW_mdR3-0Ho89Q-sPyS7uQBznOUtpYO5ca40-z66R19x_cPgotaBRJyoUr1EOfR7Nj-Js15lnxc21NqQZ-H8dkGdgLaYn9z3mVf0jkP9iFxEnNGWDTRrVICuYwixKvZluwZPE6dpLDAq0EiAFdApEMrmzqdcKqWR9HimNUE_c8jgsI_5C_dZV4H-Q_-6z2hZrDNVOF60Ody7nfgguwxX9kELhnzdTC7u0fCjD0bNoTI6Aw8Fk4hhsACnS6IFu50UBDXuJiRK2O15LGBp2iajdM8-hXfRpMWFN4mmSalRVNXrXpnqjWVZHi-qHC3F3XaHTRxhqgDurDAbV9LnIGzIh_rZ7k0lmPkNpO5TXYww0TBZ5ti2QUMjOqPTA7OMz-z6cUDCCrXJnxJktkriTRzgnmNsiGcBpeHbCJQMJHEYQv1w-Sp_9tsse-pL8ZnpEJdeRAUP_OAh-J-Mz2phNY7q5xune3T6kxi_v4G8NFO5q7RBLQCoih9LdXlao-NikrdV7KpncWdXEsqiReOyl-x-zzkJDAhRloQMwI70HsS_dMYVlbYt9hXA2pgNEBRg2Xu-4HDFoA5fQtZjbVuveCITnXQ3ox3GsyFbnOB-hiQFS9YOhbDUINeUTrQ3SLHa9SQl-RHxGOZpzN49rlR5AO1j_u7VkzqetFt3-RDAOSOQsvnud7FPn-FGLAvUGFIbTXs6m8jN7nV5QeGJ_G2baVD1nFzSG67GP2xKypNcABDdIoWBa5AtmRTK82d_Fw3_I0qx9l33vG3C7tlc6IZ02-Bb17rFJvE97AneceRsWM1uNkyUNuOz1UxE4Uaa0PHl1fK0reqXhKoZCnMiU4d-Yxy-5qY0IgjY4zhJZiCglUJVVVnwCHVZAuSnKaL8OP-nKs6k0kIkOMFJAOb6mXggglYBXmM6uvMTfu0lFarz5teEZQdrRPWfWHqhpnoZSAcfTiK5xuC8WbSmA1xFjbLwvMKi8nCR6i5jkzmFmcOX4UCa-1IYKpZDrqNlYJdZf5EosAAeqbIUxG7KxuMGX8J6gibzCj-sHP1KUY6VgVTRvtaxA0Vbdbq5ZqvM4AtRBuaPC4GoFoPhHoaQ1qdF4BI_qoSYw0xcqGQx7u87DxHEaG3GUF7XU0lhcHMH6c9WB1Hg0CJhe9o4TSo7FnNzXpaeRLNzvg8tox95Rhz1WsRSzxAYpESZimB1TYHU_T3LruaMDDktWxFTUGhl_N2g_3SbjkGrxHdCgGiRpDBtZA2nz4y6xDAFWr3XveiyX6eVqmh7ibZ8KkZqw_3LhkvEW8hf6yv72h-y9wN7kSVaO8ZM13cxiQk2ArDDZUSV1aCA4bGLNvxHevdG2Ep-h_-Bsh9aBWjztlVmk45Tv-vw9WA2qPUq88uU0S1riEJrlyU1mdXJGzEWEz0Cg4CRzyh48VGnSDKCFt0tZXjM9k1kaU6wI7KlXNO50aWE1R7eF-uaMX5fD0Q3pZCRoCpkzDlHvQzGV0yiTVOFYcw">
        </form>
    </div>
</div>
<script>
    (function(){
        window._cf_chl_opt={
            cvId: '2',
            cZone: 'www.rokomari.com',
            cType: 'non-interactive',
            cNounce: '58894',
            cRay: '7b1c69e2ad85c690',
            cHash: 'f349b94a31caf6c',
            cUPMDTk: "\/static\/200\/assets\/common\/js\/ga4-event-emitter.js?__cf_chl_tk=klmLiDMCXIyfv8ItUHuGF1XKW3DtmPp5.Het93EaUWI-1680473549-0-gaNycGzNCLs",
            cFPWv: 'b',
            cTTimeMs: '1000',
            cMTimeMs: '60000',
            cTplV: 5,
            cTplB: 'cf',
            cK: "",
            cRq: {
                ru: 'aHR0cHM6Ly93d3cucm9rb21hcmkuY29tL3N0YXRpYy8yMDAvYXNzZXRzL2NvbW1vbi9qcy9nYTQtZXZlbnQtZW1pdHRlci5qcw==',
                ra: 'Tk9fVUE=',
                rm: 'R0VU',
                d: 'ZZxfdoVhz+LYzWYYEQ7OfNSXcPTiN2NucC4aQbASZe7jXazA5xQmjclo8zxKBbRZIRAPw31WZVEfHdxnpWByRFIQ2i6Kjx+DtiHL1rUkkRgPwNZKK+5wbDCfBS4ves+up4Qi9rtk7dnZLx62xXIJ+CeL5ny0dH3wTBzFpFxWuwdFwydxf93kmUSKijVj5E5ksb/cPhtTkIQ5+2SJhUVffXNiN5xHvrNUt5ldO9GExL93lCoMBWAavcLtCBS4NG/EGxWWDP7+PB582YBGiDn/A1V6VqDYcKtVnPjidct51+fsRVoXElcXmXjjVb+TONOL+qRsljCyCA2HZoG3cD7+z0wD31AfaQKv9sjpcdKarthZ4YNLmuvrAQqx7W2YNcfWyDjB2LzeLkHrIdTF6iiTnU8571MC/fX24Obr/ejnNnV1ddrqt7KASPtJ6QfzEhSrFatE7gqLpo/eDeCwMIuDffc/NUM67TuYRZ3oDCMxGAaVPpt0iNsIfv2RySmLCaye0jRN9RJ3cdJaR+fwFHkmaq6f43i8Hb2tEStztlHjSoILqpeUqRSQExsj5lipbWTrtka5kVDfjX/PfOtAmq76SAoUttbO78+7tup1kR39WwrS5F8rKMMhDELBHKCF15+D',
                t: 'MTY4MDQ3MzU0OS4yMzMwMDA=',
                m: '/Jw2RUhj5SWbmoWizA4PekEmKQozK1fNRL/AWBFsLFk=',
                i1: 'e6QKOUb36uVcTBtSW+7XYQ==',
                i2: 'Bmm0TClXO8ZDJd5BZNT5Rg==',
                zh: '1DVRNAlOk2GcTXXG7AR1pZWNZiJTq6j1VBfddTmyiJI=',
                uh: 'DV4j3Tmrbi5Rs1q3ahwVS6SgbPbI7np5884QO1u1Cgg=',
                hh: 'sZG2UFeZu81C28BydsmA6yuSPCKDPnnywA2izalVuLk=',
            }
        };
        var trkjs = document.createElement('img');
        trkjs.setAttribute('src', '/cdn-cgi/images/trace/jsch/js/transparent.gif?ray=7b1c69e2ad85c690');
        trkjs.setAttribute('alt', '');
        trkjs.setAttribute('style', 'display: none');
        document.body.appendChild(trkjs);
        var cpo = document.createElement('script');
        cpo.src = '/cdn-cgi/challenge-platform/h/b/orchestrate/jsch/v1?ray=7b1c69e2ad85c690';
        window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;
        window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;
        if (window.history && window.history.replaceState) {
            var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;
            history.replaceState(null, null, "\/static\/200\/assets\/common\/js\/ga4-event-emitter.js?__cf_chl_rt_tk=klmLiDMCXIyfv8ItUHuGF1XKW3DtmPp5.Het93EaUWI-1680473549-0-gaNycGzNCLs" + window._cf_chl_opt.cOgUHash);
            cpo.onload = function() {
                history.replaceState(null, null, ogU);
            };
        }
        document.getElementsByTagName('head')[0].appendChild(cpo);
    }());
</script>


</body>
</html>
