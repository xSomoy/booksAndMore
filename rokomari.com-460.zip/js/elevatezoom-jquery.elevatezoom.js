<!DOCTYPE html>
<html lang="en-US">
<head>
    <title>Just a moment...</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="/cdn-cgi/styles/challenges.css" rel="stylesheet">
    <meta http-equiv="refresh" content="35">

</head>
<body class="no-js">
    <div class="main-wrapper" role="main">
    <div class="main-content">
        <noscript>
            <div id="challenge-error-title">
                <div class="h2">
                    <span class="icon-wrapper">
                        <div class="heading-icon warning-icon"></div>
                    </span>
                    <span id="challenge-error-text">
                        Enable JavaScript and cookies to continue
                    </span>
                </div>
            </div>
        </noscript>
        <div id="trk_jschal_js" style="display:none;background-image:url('/cdn-cgi/images/trace/jsch/nojs/transparent.gif?ray=7b1c69e93dda6835')"></div>
        <form id="challenge-form" action="/static/200/vendors/elevatezoom/jquery.elevatezoom.js?__cf_chl_f_tk=w9zZy1Mrdo8ww_nD2CCilnx1mVv257mWS8HhtiCFgEg-1680473550-0-gaNycGzNCNA" method="POST" enctype="application/x-www-form-urlencoded">
            <input type="hidden" name="md" value="WgBI0MBlDuQryTVW6wYVJeeFHoguooXCpDYqrxOowIc-1680473550-0-AfOb2mytXx0FU_VlaJ07BE_5MiZ7o-tqiJX7p-FQLATSOLXE-vOVFWy7IWZU1-yrJn8TEXMedy6tRfe6BVZkcXtfP8UulBK8ZczoBMeRng38BD8PJfknORRUs3RtatmY8BcK1_Nd0WzYy3UYPDd-WUjw9-1Y3DqEmgTigSkRVYJSADhvMwrkLBrKxSCrwJ2n_ah3GzRuXzP36XXvTUIGBzXzeZesvY-r3VcQugaSg3b9CsBgNBPNz0FpS0rebCQ55Nz6gmOtUJocl923Gtupiq5rkLCeIzz3MCIIoa4tz98ey45sgqZQ7EF1MsfaBJ7cJEeHZlDZCRe10DiLk2E_xzgc853YEWzCANa0saG2-hgAvSlIVoc9emee5PN3BZtR10sfb0vMem38V1W2q9IicJX-JO-wijsgcf5bPcgKARuNNUwrfiim4cs5onWJUK48josWTc9fpz43GlBgx43s3q24rGLyhzd5JZX75IdDF8fNJqYSuVNZDVWspP_xGAOlXM3NJIB97J9DGP6VvtBrXoHK2KH_TDw0wsg4zRc3u4jcZaVEz5e6k5uRC0EOEJpJqKCbB_AQxsPTWoXKul6J9nv6s6MsgIVeITtX7utA3K3shRjgwq_ze-y5inUxO9SXU1pRmluSc_Jx2ZCJB6me3T-Nb4dW_-YpnqyG0HY7uCwbiPKkcc3qv5RnC8aRQw-6Q4iQeM8RhU2x20nVikmcb_RZlDl2_DIOl5oLISnlwgM0mbE9k2TjtbZq_Qgk9MKWx_GsZWNvXzHKa5FarbF-S3JEHIerFvKJLV4Db8ORR7psd28ctFlixh8gpnLk7sXgxAuvusHRMzmXUvv9QaEhh0XgppYK0JJKt1XDorIawSik1NR2i6aiTGXBthLUv7XRWY83sGav4vcbMSMBcyvqvSs_j9c_yjKe5sIIbSgloP-NIejZVDgtFgrbQ68ClfgsJxhuxtRbd6g9fC1Uo-laQxlDzLjL2lhnniB6cPN0L3OesM_M1b_eF2leX3RCM0uxun-pEVXHwo3snYvf8Y8D9gmcb1HWLnBYQbP5uym4gUYJ3EGIO3PdM7PugjNxg5WotIE9TUUeDl3VslqhYcVbCJzTHDpuHnCQVJEsbIZ8zFSmEtJksJLhPInboquUcWjxXwObuqIpuLhXcZGDq73w8W13T6D9f6J6dz8FZMzW1Gb745p_uHsd653KljlN46d1Rux0MoSZSEmtXNwa2xm40Fv9RhTd5u-hmKEqZ1vcIs2l9m1Jxwbcm2-e5BXjXjN8yxZtEoe90iTPvO_ntHOFYzPl-XEALaeeco9MBhv2gnxEDceBXBfDtomKN33M2OqBJ9ER7pZUC_4KD0uOAyXBhhQd6czhemsOpyNqhsS3nE5qw-I2pqu-6sGEExdPq5Ljqqc0eBTHr3oxi6zoFQATNvvz7UmptRN3fb8Fl31kB0OFHiuxc__5zXaTURwTqv4amgTHKq6JLF4bnv5c0hlGk6LUXPxwATcGFFqTZ4SOtgMp6doVHjQipa3_zi_AK17mslgthhT3JsKBGRXtQRZAAPRGv7PN8AtwOsuHnpCez_dQFEhfy6jZ8Ga4nH8-T7aEs8lRsevbDqvf1DQwJRLJt94NXnSKLmbJ8wni5PkC-cW3XrG5JDlxuR1Hb1MA9JzoS1l7QREuLYCDMvnrOq9eVN0KElHTZO1dL6fc7Fcla2cGnVtvXDM9HhXRtk429XWzFwd3znDXz7BVlIT14xabP7tFuTYSYYozqdR-UoiTfGCOIBWPmVTRy-T3nPex58Fr3iLuCjiSmgLmjpQcxhDMgaBwOwZ8AQN3uAdob4-75b4Aq6DR-3dsMhdDQDwmPmit70xkvMx3_SSDY_RX5-6BDND4xo_dUt2JUi_fima-YgEDMbFZY20DamqGlm6MgQR3H3MLZeYPqujDPEhU0AwGa4DTUMT4ODxMy0IvZv4TDIHwuTRLbIppaOd9AY1vZ9e0S_ig3YpCz4mraT-DVUhtGrIqe9EEAOAeLpJTVb31PZpMBKsG6ebIYreXLWAuOsxegJghNd3u1ulxO0ZB9SMXZwHIJSTHmIkEmCtxpWgmZVS0xf2kZ_liOguav7ysfuOu1_MDS0ebi9IV9BeqSTBLJeTAZfpTBD0P3rsQVS5ch52xWysQOddstXs3rQ6v1jyuxE2EokfzDYIutE7JyrlJSlA">
        </form>
    </div>
</div>
<script>
    (function(){
        window._cf_chl_opt={
            cvId: '2',
            cZone: 'www.rokomari.com',
            cType: 'non-interactive',
            cNounce: '87486',
            cRay: '7b1c69e93dda6835',
            cHash: '2b896dc4176f61d',
            cUPMDTk: "\/static\/200\/vendors\/elevatezoom\/jquery.elevatezoom.js?__cf_chl_tk=w9zZy1Mrdo8ww_nD2CCilnx1mVv257mWS8HhtiCFgEg-1680473550-0-gaNycGzNCNA",
            cFPWv: 'b',
            cTTimeMs: '1000',
            cMTimeMs: '60000',
            cTplV: 5,
            cTplB: 'cf',
            cK: "",
            cRq: {
                ru: 'aHR0cHM6Ly93d3cucm9rb21hcmkuY29tL3N0YXRpYy8yMDAvdmVuZG9ycy9lbGV2YXRlem9vbS9qcXVlcnkuZWxldmF0ZXpvb20uanM=',
                ra: 'Tk9fVUE=',
                rm: 'R0VU',
                d: 'ZLfam99aT6b17nMcpSRqQU0fmaQ+CO2Jb30RgFtW60GXI7qCryHIxZ9qEqPYj5Q2Zt7EkkRSeXAKZ2vijwiNen9EvC5xi6tGtv1xG0ghhcPDEkUwmiaM/nyGnhdmWvd5e47uuNy4SeeiNBk9UnxRTj+hk3GnLWZQUuYHgMBGm+pXiOOS50PviRGYnHrsdeGHNdlsXKBtgmLGBnyKQBwTwXcKSsiJEkiy1/JH7qXki/lyUDhuWwPDwt62DLan9jIR/74KeNo34qcHhn5jtzbkuS+tOFKdJj73MxfZeud7fjpFzC9Gp/z96CWmyobFpINJYFVUR5rD82R6jMMYqx2HpTwB7BUamuQWAWBZx7nruBZi8OZRfRhvpv2OpLK5Vjs0kmVvRTOK4bJhBBaYdm8bHGSVpGL9NRkldX890FeQFJsXicm5Mpam/x6DYPBJxzsvIefE9BD8Ti3vmP7LFKUvJJfDT4ge3Bn2lHQwlqohaLO7Sw0btVGJRN4R4hRsGsjbPS1Zv0sC8HoXZUWEkQDKB32h/Px7bUn4lZMQUADJWpXICIQyPmptokTyHe5UIjrTXr1MDxkKn+JPktKgu0YzX8r+ru043TRpY88bCXY9ok4dj3Fd8iV96QmD3xMmMwOM',
                t: 'MTY4MDQ3MzU1MC4yNzYwMDA=',
                m: 'OXMlLG3vCPe7YESt6yLQtZzi2H6ZfrtM69PWYuGzqpk=',
                i1: 'o9HLYGQdMpUqJIKUuFSw9Q==',
                i2: 'sYJMw3Us+owF00ZgwrZ7Jw==',
                zh: '1DVRNAlOk2GcTXXG7AR1pZWNZiJTq6j1VBfddTmyiJI=',
                uh: 'DV4j3Tmrbi5Rs1q3ahwVS6SgbPbI7np5884QO1u1Cgg=',
                hh: 'sZG2UFeZu81C28BydsmA6yuSPCKDPnnywA2izalVuLk=',
            }
        };
        var trkjs = document.createElement('img');
        trkjs.setAttribute('src', '/cdn-cgi/images/trace/jsch/js/transparent.gif?ray=7b1c69e93dda6835');
        trkjs.setAttribute('alt', '');
        trkjs.setAttribute('style', 'display: none');
        document.body.appendChild(trkjs);
        var cpo = document.createElement('script');
        cpo.src = '/cdn-cgi/challenge-platform/h/b/orchestrate/jsch/v1?ray=7b1c69e93dda6835';
        window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;
        window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;
        if (window.history && window.history.replaceState) {
            var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;
            history.replaceState(null, null, "\/static\/200\/vendors\/elevatezoom\/jquery.elevatezoom.js?__cf_chl_rt_tk=w9zZy1Mrdo8ww_nD2CCilnx1mVv257mWS8HhtiCFgEg-1680473550-0-gaNycGzNCNA" + window._cf_chl_opt.cOgUHash);
            cpo.onload = function() {
                history.replaceState(null, null, ogU);
            };
        }
        document.getElementsByTagName('head')[0].appendChild(cpo);
    }());
</script>


</body>
</html>
